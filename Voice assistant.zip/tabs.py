import pyautogui
import pyttsx3
from time import sleep
import webbrowser

# Initialize the speech engine
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("voice", voices[1].id)
engine.setProperty("rate", 200)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

# Function to open a new tab in the browser
def open_new_tab(url, update_conversation):
    try:
        speak("Opening a new tab")
        update_conversation("Assistant: Opening a new tab")
        webbrowser.open_new_tab(url)
        update_conversation(f"Assistant: Opened {url} in a new tab")
    except Exception as e:
        speak(f"Sorry, I couldn't open the tab.")
        update_conversation(f"Assistant: Failed to open the tab - {str(e)}")

# Function to close a certain number of tabs in the browser
def close_tabs(tab_count, update_conversation):
    # Handling both "one" and "1" in the input
    if tab_count.lower() == "one":
        tab_count = 1
    else:
        try:
            tab_count = int(tab_count)  # Convert string digits to int
        except ValueError:
            speak("Sorry, I couldn't understand the number of tabs.")
            update_conversation("Assistant: Couldn't understand the number of tabs.")
            return

    speak(f"Closing {tab_count} tab(s).")
    update_conversation(f"Assistant: Closing {tab_count} tab(s)")

    for _ in range(tab_count):
        pyautogui.hotkey("ctrl", "w")
        sleep(0.5)  # Small delay between closing tabs
    speak(f"{tab_count} tab(s) closed.")
    update_conversation(f"Assistant: {tab_count} tab(s) closed.")
